---
title: "E = MC ²"
artists: ["David X"]
labels: ["GFB Records"]
styles: ["Techno", "Italo House"]
---

## David X - E = MC ²


### Labels
GFB Records
### Styles
Techno, Italo House