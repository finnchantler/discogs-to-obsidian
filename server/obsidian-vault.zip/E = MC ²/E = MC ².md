---
title: "E = MC ²"
artists: ["David X"]
labels: ["GFB Records"]
styles: ["Techno", "Italo House"]
---

# E = MC ²
## Artists
David X
## Labels
GFB Records
## Styles
Techno, Italo House