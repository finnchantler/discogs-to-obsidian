## Releases
```dataview
table title, artists, labels, styles
from ""
where file.name != "Home.md"
```